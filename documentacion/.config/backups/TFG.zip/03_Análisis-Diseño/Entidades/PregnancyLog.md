# Entidad: PregnancyLog

Registra datos sobre embarazos.

- start_date, due_date, ultrasound_date
- notes, symptoms
- ManyToOne → User
