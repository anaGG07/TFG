# Entidad: MenopauseLog

Registra síntomas y fechas relacionadas a la menopausia.

- startDate, confirmedDate
- booleans: hotFlashes, moodSwings, etc.
- OneToOne → User
