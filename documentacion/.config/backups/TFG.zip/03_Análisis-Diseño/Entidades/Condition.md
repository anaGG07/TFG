# Entidad: Condition

Condiciones posibles que puede tener una usuaria.

- name, description, chronic
- OneToMany ← UserCondition
