# Entidad: GuestAccess

Permite que otro usuario acceda al perfil.

- ownerUser, guestUser (ManyToOne)
- accessTo (JSON)
- guestType (enum)
