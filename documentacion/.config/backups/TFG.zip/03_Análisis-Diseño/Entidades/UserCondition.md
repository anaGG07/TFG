# Entidad: UserCondition

Relación entre User y Condition.

- start_date, end_date, notes
- ManyToOne → User
- ManyToOne → Condition
