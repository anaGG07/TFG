# Entidad: SymptomLog

Registro de síntomas diarios.

- symptom, intensity, note
- date
- ManyToOne → User
