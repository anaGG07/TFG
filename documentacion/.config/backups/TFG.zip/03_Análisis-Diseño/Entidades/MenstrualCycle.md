# Entidad: MenstrualCycle

Registra un ciclo menstrual de la usuaria.

- start_date, end_date, estimated_next_start
- pain_level, flow_amount
- Relación ManyToOne → User
