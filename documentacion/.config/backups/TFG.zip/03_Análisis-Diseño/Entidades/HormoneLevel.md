# Entidad: HormoneLevel

Niveles hormonales registrados por la usuaria.

- hormoneName, level (float), unit
- date
- ManyToOne → User
