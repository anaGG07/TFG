# Diferenciación de EYRA respecto a otras soluciones

## Introducción

EYRA nace como una respuesta consciente y tecnológica a las carencias observadas en las aplicaciones actuales de seguimiento del ciclo menstrual. Su diseño no solo busca cubrir necesidades fisiológicas, sino también emocionales, sociales e identitarias, muchas veces invisibilizadas.

A diferencia de otras plataformas del mercado, EYRA no se limita a registrar fechas o síntomas, sino que se posiciona como un espacio **de acompañamiento integral, inclusivo y basado en ciencia**, para mujeres, personas menstruantes y personas en transición de género.

---

## ¿Qué hace diferente a EYRA?

###  1. Enfoque inclusivo y respetuoso

- Contempla distintos tipos de identidad (mujer, trans, no binaria, pareja)
- Usa lenguaje y diseño no estereotipado
- No reduce la salud femenina al ciclo reproductivo

###  2. Acompañamiento basado en evidencia científica

- Se prevé la integración de una IA que responda con base en papers revisados
- Ofrece explicaciones fisiológicas y hormonales durante cada fase del ciclo
- Brinda consejos y recomendaciones según estado corporal real

###  3. Registro amplio y profundo

- Niveles hormonales, síntomas físicos y emocionales, estados anímicos
- Historial personalizado
- Seguimiento de condiciones como endometriosis, menopausia, embarazo

###  4. Participación del entorno

- Permite a parejas seguir el estado emocional/físico de la usuaria
- Fomenta la empatía, el diálogo y la comprensión de la experiencia femenina
- Alertas personalizadas para la pareja (ej: "hoy es buen día para mimar")

###  5. Plataforma web accesible

- EYRA nace como una plataforma web completa desde el inicio
- No requiere instalación ni sistema operativo específico
- Contrasta con apps del mercado que solo ofrecen versiones móviles o SPAs limitadas

###  6. Escalabilidad tecnológica

- Arquitectura pensada para extenderse a móvil y wearables
- Base Symfony + React escalable y segura
- Integración futura de recomendaciones inteligentes, predicciones y más

---

## Comparativa rápida

| Característica                      | EYRA | Apps existentes                       |
| ----------------------------------- | ---- | ------------------------------------- |
| Inclusividad de género              | ✔    | Parcial o nula                        |
| IA basada en ciencia                | ✔    | No disponible                         |
| Participación de pareja             | ✔    | Limitada                              |
| Seguimiento hormonal profundo       | ✔    | Superficial                           |
| Plataforma web completa             | ✔    | No disponible / limitada              |
| Lenguaje no estereotipado           | ✔    | No siempre                            |
| Salud emocional + física            | ✔    | Centrado en menstruación o fertilidad |
| Experiencia sin publicidad agresiva | ✔    | Frecuente                             |
| Estética coherente y respetuosa     | ✔    | Infantilizada o inconexa              |

---

## Conclusión

EYRA se diferencia no solo por su tecnología, sino por su enfoque. Es una herramienta pensada desde el respeto, la diversidad y la ciencia. Un lugar donde las personas menstruantes puedan conocerse, entenderse y sentirse acompañadas. Una app que no reduce, sino que amplifica la experiencia femenina desde lo humano y lo digital.
