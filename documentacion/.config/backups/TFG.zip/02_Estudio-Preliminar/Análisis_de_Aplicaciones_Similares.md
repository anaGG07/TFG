# Análisis de Aplicaciones Similares

## Introducción

Antes de desarrollar EYRA, se ha realizado un análisis de aplicaciones existentes en el ámbito del seguimiento menstrual y la salud femenina, con el fin de identificar aciertos, carencias y oportunidades de mejora. Este análisis sirve para posicionar EYRA dentro del ecosistema actual de soluciones digitales orientadas al bienestar hormonal y emocional de las mujeres y personas menstruantes.

---

## Aplicaciones Analizadas

### 1. Clue

**Descripción**:  
App de seguimiento del ciclo menstrual basada en ciencia. Ofrece análisis de patrones, predicción de ciclos y permite registrar síntomas físicos y emocionales.

**Puntos fuertes**:
- Interfaz móvil limpia y moderna
- Rigurosidad científica
- Sin lenguaje ni símbolos estereotipados

**Limitaciones**:
-  Tiene versión web limitada: [helloclue.com](https://helloclue.com/es), pero...
  - No permite registrarse sin suscripción
  - No cuenta con una interfaz de navegación completa
  - Es una SPA muy básica, sin acceso a funcionalidades clave
  - El diseño web no sigue la estética de la app móvil: colores distintos, falta de coherencia visual
- No incluye contexto de personas trans o en transición
- Escasa personalización en el flujo de fases
- Requiere pago para algunas funcionalidades clave

---

### 2. Flo

**Descripción**:  
App popular para el seguimiento del ciclo menstrual, con predicción de ovulación y contenido educativo integrado.

**Puntos fuertes**:
- Gran base de usuarios
- Información abundante y variada
- Comunidad y foros

**Limitaciones**:
- ❌ No tiene versión web funcional (solo sitio informativo)
- Solo permite usar el calendario de forma gratuita
- Proceso de registro largo, lleno de preguntas antes de acceder
- Experiencia inicial muy lenta y poco fluida
- Ventanas de suscripción constantes que interrumpen la navegación
- Abuso de gamificación y estética infantilizada
- Enfoque excesivamente reproductivo (centrado en fertilidad)
- Poca claridad sobre privacidad de datos

---

### 3. Maya

**Descripción**:  
App de salud femenina que combina predicción del ciclo, control de síntomas y recomendaciones generales de bienestar.

**Puntos fuertes**:
- Registro de síntomas
- Personalización del ciclo

**Limitaciones**:
- ❌ No tiene versión web
- En la fase de prueba, no registró correctamente el ciclo
- Se establece por defecto el seguimiento de embarazo
- No es inclusiva para personas no binarias o trans
- Interfaz poco adaptada a diversidad de experiencias
- Interfaz incómodamente infantilizada

---

### 4. Cycles

**Descripción**:  
App centrada en el seguimiento del ciclo y la comunicación en pareja.

**Puntos fuertes**:
- Compartir el ciclo con la pareja
- Proceso de registro rápido

**Limitaciones**:
- ❌ No tiene versión web (solo iOS)
- Muy centrada en seguimiento menstrual
- No es inclusiva para personas no binarias o trans
- Abuso de suscripciones para realizar cualquier acción
- Interfaz simple, sin opciones más allá de registrar el ciclo

---

## Conclusiones del Análisis

El análisis de estas aplicaciones revela que, si bien existen herramientas sólidas en términos de predicción y registro de ciclos, aún quedan áreas sin cubrir adecuadamente:

- Falta de enfoque inclusivo (personas trans, no binarias)
- Baja representación del componente emocional y psicológico del ciclo
- Escasa conexión entre fases hormonales y acciones diarias (ejercicio, alimentación, etc.)
- Pocas integraciones sociales reales (parejas, entorno)
- ❌ Solo una app ofrece versión web, y solo para registro.
- Infantilización del periodo, intentando restar importancia a un proceso real de la vida

EYRA surge precisamente como respuesta a estas carencias, proponiendo una plataforma que combine ciencia, tecnología e inclusión para una experiencia más rica, accesible y transformadora. EYRA se diseñará **como una plataforma web desde su inicio**, garantizando el acceso multiplataforma sin necesidad de instalación ni limitaciones de sistema operativo.
