# Tecnologías Relacionadas

## Introducción

El desarrollo de EYRA se apoya en una arquitectura tecnológica moderna y escalable que permite cubrir las necesidades funcionales del sistema en esta fase y habilita su evolución futura. A continuación se describen las tecnologías principales empleadas y su papel dentro del proyecto.

---

## Tecnologías utilizadas

###  Symfony (Backend)

**Descripción**: Framework PHP moderno para el desarrollo de aplicaciones web robustas y mantenibles.

**Razones para su elección**:
- Alto rendimiento y escalabilidad
- Integración con Doctrine ORM para gestión de entidades y relaciones
- Ecosistema maduro, estable y bien documentado
- Seguridad integrada y personalizable

**Uso en EYRA**:
- Lógica de negocio
- Gestión de usuarios y roles
- Conexión con base de datos
- Estructura de endpoints para el frontend

---

### PostgreSQL (Base de datos)

**Descripción**: Sistema de gestión de bases de datos relacional, potente y de código abierto.

**Ventajas clave**:
- Alto rendimiento y consistencia
- Soporte nativo de tipos como JSON y enum
- Amplio soporte en entornos de producción

**Uso en EYRA**:
- Persistencia de datos de usuarios, ciclos, síntomas, alertas, etc.
- Soporte a relaciones complejas entre entidades

---

### React + TypeScript (Frontend)

**Descripción**: Biblioteca para interfaces dinámicas y declarativas. Se emplea con TypeScript para mayor robustez.

**Ventajas clave**:
- Componentización reutilizable
- Interfaz moderna y rápida
- Ecosistema ideal para futura app móvil (React Native)

**Uso en EYRA**:
- Formularios de registro y login
- Visualización de datos del ciclo y síntomas
- Escalabilidad futura hacia dispositivos móviles

---

###  Doctrine ORM

**Descripción**: Mapeo objeto-relacional usado con Symfony para interactuar con la base de datos como si fuera código PHP.

**Ventajas clave**:
- Facilita la gestión de relaciones complejas
- Automatización de migraciones
- Definición clara de entidades

**Uso en EYRA**:
- Modelo de datos (entidades, relaciones, repositorios)
- Generación de migraciones y sincronización con PostgreSQL

---

## Tecnologías futuras previstas

###  Inteligencia Artificial (OpenAI / NLP)

- Integración futura de un asistente inteligente basado en lenguaje natural
- Respuestas basadas en artículos científicos y papers validados
- Acompañamiento emocional, hormonal y educativo

---

## Conclusión

La combinación de Symfony, PostgreSQL y React ofrece una arquitectura sólida, segura y preparada para escalar. EYRA ha sido diseñada para aprovechar estas herramientas en su fase actual y seguir creciendo hacia funcionalidades avanzadas con inteligencia artificial, visualización de datos y soporte móvil.
