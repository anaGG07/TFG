# Contexto del Proyecto - EYRA

## Introducción

EYRA es una aplicación web orientada al seguimiento y acompañamiento de la salud femenina a lo largo de las diferentes etapas de la vida. Su principal objetivo es cubrir un vacío tecnológico y social que afecta a millones de mujeres, personas menstruantes y personas en procesos de transición de género, permitiéndoles registrar, entender y gestionar sus ciclos menstruales, hormonales y sintomatológicos de forma personalizada, inclusiva y científica.

El proyecto nace como respuesta a una necesidad latente: la falta de herramientas digitales completas, inclusivas y respetuosas con la diversidad de identidades que permita a las personas menstruantes tener control y comprensión sobre sus procesos fisiológicos, emocionales y hormonales.

## Justificación del Proyecto

Hoy en día, la mayoría de aplicaciones de seguimiento menstrual existentes están centradas únicamente en el registro de la fecha de menstruación y ovulación, dejando de lado aspectos fundamentales como:

- Cambios hormonales detallados
- Síntomas físicos y emocionales asociados
- Fases del ciclo y cómo afectan al bienestar
- Inclusión de personas trans y no binarias
- Interacción con personas del entorno (pareja, acompañantes)
- Seguimiento del embarazo, la menopausia o condiciones como la endometriosis

Además, existe una desconfianza generalizada por parte de muchas mujeres y personas menstruantes hacia los sistemas sanitarios tradicionales, lo que dificulta el acceso a información rigurosa y apoyo emocional durante sus fases vitales.

EYRA busca ser un espacio digital de confianza, acompañado de un asistente inteligente con base científica, que ayude a suplir esta carencia y ofrezca acompañamiento real.

## Problemas Detectados

- Invisibilización de los síntomas menstruales y hormonales en la atención médica general
- Falta de educación y autoconocimiento sobre el ciclo menstrual y las fases hormonales
- Falta de apps centradas en la diversidad de experiencias femeninas
- Escasa participación del entorno afectivo (parejas) en la comprensión del ciclo
- Baja accesibilidad a contenidos científicos verificados sobre salud femenina

## A quién se dirige EYRA

EYRA está pensado para acompañar a:

- Mujeres y personas menstruantes que deseen registrar y entender su salud
- Personas en transición de género que necesiten controlar su proceso de hormonación
- Parejas que quieran comprender las fases emocionales y físicas de su compañera
- Personas que atraviesan la etapa de menopausia, embarazo o condiciones crónicas

## Enfoque Tecnológico

El sistema se desarrolla en dos capas principales:
- Backend: Symfony + PostgreSQL (robustez, seguridad, estructura clara de entidades)
- Frontend: React + TypeScript (escalabilidad futura a móvil con tecnologías como React Native)

Además, se prevé la integración futura de inteligencia artificial para que la usuaria pueda consultar dudas relacionadas con su salud de forma anónima, segura y con rigor científico.

## Valor Añadido de EYRA

- Inclusividad: contemplación de identidades diversas
- Personalización: fases del ciclo, alertas, síntomas y recomendaciones
- Cientificidad: base en papers y estudios validados
- Accesibilidad emocional: espacio seguro de autoconocimiento y acompañamiento

