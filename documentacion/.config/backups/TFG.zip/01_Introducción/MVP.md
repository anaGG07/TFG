# MVP - Funcionalidades mínimas viables del sistema EYRA

Este documento recoge las funcionalidades mínimas necesarias que debe incluir la plataforma en su versión inicial para ser considerada **funcional y útil** desde el punto de vista de la usuaria. Esta definición de MVP (Minimum Viable Product) tiene como objetivo establecer una base clara y alcanzable para el desarrollo del sistema, permitiendo validar su utilidad sin necesidad de implementar todas las ideas previstas para el futuro.

El MVP se ha definido teniendo en cuenta:
- El problema que busca resolver EYRA
- El tiempo disponible para el desarrollo
- La viabilidad técnica en el entorno definido (Symfony + React)
- La escalabilidad futura (hacia móvil, IA, acompañamiento de pareja, etc.)

---

## Objetivo del MVP

Construir una plataforma web funcional para el **registro y seguimiento del ciclo menstrual y síntomas relacionados con la salud femenina**, que permita a la usuaria:
- Gestionar su perfil y sus registros personales
- Registrar sus ciclos menstruales
- Anotar síntomas y niveles hormonales
- Visualizar su historial
- Recibir alertas básicas útiles

---

## Funcionalidades MVP

###  1. Autenticación y Gestión de Usuario

- [ ] Registro de usuarias (email, contraseña, nombre)
- [ ] Login / Logout seguro
- [ ] Gestión del perfil (nombre, apellidos, fecha de nacimiento, identidad de género)
- [ ] Selección de tipo de perfil (`mujer`, `pareja`, `en transición de género`)
- [ ] Roles básicos (`ROLE_USER`)

###  2. Ciclo Menstrual

- [ ] Registrar inicio y fin de un ciclo
- [ ] Visualizar historial de ciclos
- [ ] Estimar próxima menstruación (función básica de predicción)
- [ ] Modificar/eliminar ciclos registrados

###  3. Síntomas

- [ ] Añadir síntomas con nombre, intensidad y fecha
- [ ] Visualizar síntomas por día
- [ ] Editar y eliminar síntomas

### 4. Hormonas

- [ ] Registrar niveles hormonales: nombre, valor, unidad, fecha
- [ ] Visualizar historial de niveles por hormona

### 5. Alertas

- [ ] Generar alerta automática antes del siguiente ciclo
- [ ] Alerta manual (ej: recordar compra de productos)
- [ ] Marcar alerta como leída

### 6. Condiciones de salud

- [ ] Ver lista de condiciones 
- [ ] Asociar una condición a la usuaria
- [ ] Visualizar condiciones actuales


---

## Conclusión

Definir este MVP permite mantener el desarrollo enfocado y garantizar que, aun con recursos limitados, el sistema EYRA cumpla con su propósito inicial: **acompañar a las mujeres en el conocimiento y gestión de su salud menstrual**.

Estas funcionalidades representan el mínimo esencial para entregar valor real a la usuaria y sentar las bases para futuras extensiones del sistema.
