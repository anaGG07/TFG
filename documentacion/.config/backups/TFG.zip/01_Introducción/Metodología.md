# Metodología del Proyecto - EYRA

## Enfoque de trabajo

El desarrollo del proyecto EYRA ha seguido una metodología ágil, centrada en ciclos iterativos de desarrollo que permiten validar avances funcionales y ajustar prioridades de forma flexible. El objetivo ha sido construir un producto mínimo viable (MVP) funcional, que siente las bases para un sistema escalable, robusto y mantenible.

---

## Fases de desarrollo

### 1. Análisis y diseño inicial
- Definición de requerimientos funcionales
- Diseño del modelo de datos (entidades y relaciones)
- Planificación de funcionalidades MVP
- Creación de bocetos iniciales y estructura en Obsidian

### 2. Configuración del entorno
- Instalación de Symfony y PostgreSQL
- Configuración de entorno de desarrollo local
- Integración con sistema de control de versiones (Git)

### 3. Desarrollo del backend
- Creación de entidades Doctrine
- Generación y aplicación de migraciones
- Definición de relaciones y validaciones
- Implementación de lógica de negocio básica
- Gestión de autenticación y roles

### 4. Desarrollo del frontend base
- Estructura inicial en React + TypeScript
- Conexión con endpoints del backend
- Formularios para ciclos, síntomas y perfil
- Estilo y diseño adaptado a usuarias

### 5. Documentación técnica
- Estructura documental en Obsidian
- Explicación de entidades, relaciones y flujos
- Registro de decisiones técnicas

### 6. Validación y pruebas
- Pruebas funcionales manuales del backend
- Verificación de datos en PostgreSQL
- Test de interacción básica con el frontend

---

## Herramientas utilizadas

- **Symfony**: framework backend robusto, modular y escalable
- **Doctrine ORM**: mapeo objeto-relacional para la base de datos
- **PostgreSQL**: motor de base de datos
- **React + TypeScript**: desarrollo frontend
- **Obsidian**: sistema de documentación y seguimiento del TFG
- **Git + GitHub**: control de versiones y gestión de código

---

## Justificación de la metodología

El uso de un enfoque iterativo ha permitido ajustar el desarrollo a los tiempos y recursos disponibles, priorizando la funcionalidad crítica (MVP) sin perder de vista la escalabilidad futura.

Documentar y validar cada paso en paralelo al desarrollo ha sido clave para asegurar la coherencia del sistema y facilitar futuras evoluciones tecnológicas.

