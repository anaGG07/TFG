
const AdminPage = () => {
  return (
    <div>
      <h1>Panel de Administración</h1>
      <p>Bienvenido/a, administrador/a. Aquí puedes gestionar el sistema.</p>
      {/* Aquí puedes agregar gestión de usuarios, contenido, estadísticas, etc. */}
    </div>
  );
};

export default AdminPage;
